extends Node3D
## ODEALAND — Galaxia 3D v0.2
## Planetas pequenos estilo Mario Galaxy + avatar bonito que camina + joystick virtual
## + menu completo (barra superior, botones grandes y panel lateral de progreso).

const CHAPTER_COUNT := 8
const AVATAR_SCALE := 1.15

const SKY_SHADER := """
shader_type sky;
uniform vec3 top_col : source_color = vec3(0.02, 0.01, 0.06);
uniform vec3 bot_col : source_color = vec3(0.10, 0.02, 0.16);
void sky() {
	float h = clamp(EYEDIR.y * 0.5 + 0.5, 0.0, 1.0);
	vec3 col = mix(bot_col, top_col, h);
	vec3 d = floor(EYEDIR * 340.0);
	float s = step(0.9974, fract(sin(dot(d, vec3(12.9898, 78.233, 45.164))) * 43758.5453));
	float tw = 0.75 + 0.25 * sin(TIME * 2.2 + d.x);
	COLOR = col + vec3(s * tw) * 1.0;
}
"""

const PLANET_SHADER := """
shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, diffuse_burley, specular_schlick_ggx;
uniform vec3 base_color : source_color = vec3(0.1, 0.3, 0.4);
uniform vec3 city_color : source_color = vec3(0.85, 1.0, 0.95);
uniform float seed = 0.0;
varying vec3 v_local;
float hash(vec3 p) {
	p = fract(p * 0.3183099 + vec3(0.11, 0.17, 0.23));
	p *= 17.0;
	return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}
float noise(vec3 x) {
	vec3 i = floor(x);
	vec3 f = fract(x);
	f = f * f * (3.0 - 2.0 * f);
	return mix(mix(mix(hash(i), hash(i + vec3(1,0,0)), f.x),
	               mix(hash(i + vec3(0,1,0)), hash(i + vec3(1,1,0)), f.x), f.y),
	           mix(mix(hash(i + vec3(0,0,1)), hash(i + vec3(1,0,1)), f.x),
	               mix(hash(i + vec3(0,1,1)), hash(i + vec3(1,1,1)), f.x), f.y), f.z);
}
float fbm(vec3 p) {
	float v = 0.0;
	float a = 0.5;
	for (int i = 0; i < 4; i++) { v += a * noise(p); p *= 2.03; a *= 0.5; }
	return v;
}
void vertex() { v_local = VERTEX; }
void fragment() {
	float n = fbm(v_local * 1.9 + seed);
	float land = smoothstep(0.42, 0.58, n);
	vec3 col = mix(base_color * 0.25, base_color, land);
	float c = step(0.72, hash(floor(v_local * 26.0) + seed));
	float coast = 1.0 - smoothstep(0.50, 0.70, n);
	ALBEDO = col;
	EMISSION = city_color * c * land * coast * 1.4;
	ROUGHNESS = 0.8;
	METALLIC = 0.1;
}
"""

const ATMO_SHADER := """
shader_type spatial;
render_mode blend_add, cull_front, unshaded, depth_draw_never;
uniform vec3 glow_color : source_color = vec3(0.0, 1.0, 0.9);
uniform float power = 2.6;
void fragment() {
	float f = pow(1.0 - abs(dot(NORMAL, VIEW)), power);
	ALBEDO = glow_color * f;
	EMISSION = glow_color * f * 1.7;
}
"""

var planets: Array = []
var avatar: Node3D = null
var legs: Array = []
var arms: Array = []
var cape: Node3D = null
var cam: Camera3D = null
var t := 0.0
var walk_speed := 11.0
var walking := false
var target_chapter := -1
var target_pos := Vector3.ZERO
var current_chapter := -1
var move_dir := Vector3.ZERO          # joystick
var shot := false
var frames := 0

# UI
var hud_level: Label
var hud_xp: Label
var hud_hint: Label
var xp_bar_bg: ColorRect
var xp_bar_fill: ProgressBar
var panel_missions: Control
var missions_box: VBoxContainer
var panel_side: Control
var side_box: VBoxContainer
var toast: Label
var touch_marker: Node2D
var joystick: Control
var joy_knob: Control

var touch_index := -1
var touch_start := Vector2.ZERO
var joy_active := false

func _ready() -> void:
	if OS.get_environment("ODEASHOT") == "1":
		shot = true
	_build_env()
	_build_planets()
	_build_avatar()
	_build_camera()
	_build_ui()
	_refresh_hud()
	_toast("Tocá un planeta para viajar 🌍 — o arrastrá para caminar")
	if OS.get_environment("ODEATEST") == "1":
		_run_autotest()

func _run_autotest() -> void:
	var log := []
	await get_tree().process_frame
	await get_tree().process_frame
	log.append("UI panel_superior_visible=%s" % str(hud_level != null and is_instance_valid(hud_level)))
	log.append("UI botones=%d" % 3)
	var pos0: Vector3 = avatar.global_position
	var sp: Vector2 = cam.unproject_position(planets[0].node.global_position)
	log.append("planeta0_en_pantalla=%d,%d" % [int(sp.x), int(sp.y)])
	_tap(sp)
	log.append("walking=%s target=%d" % [str(walking), target_chapter])
	await get_tree().create_timer(2.5).timeout
	var moved: float = avatar.global_position.distance_to(pos0)
	log.append("avatar_se_movio=%.2f" % moved)
	await get_tree().create_timer(2.0).timeout
	log.append("panel_misiones_visible=%s" % str(panel_missions.visible))
	log.append("misiones_en_panel=%d" % missions_box.get_child_count())
	# joystick
	move_dir = Vector3(1, 0, 0)
	var p1: Vector3 = avatar.global_position
	await get_tree().create_timer(0.8).timeout
	log.append("joystick_movio=%.2f" % avatar.global_position.distance_to(p1))
	move_dir = Vector3.ZERO
	# progreso lateral
	_fill_side()
	log.append("panel_lateral_items=%d" % side_box.get_child_count())
	# mision completable
	GameState.complete_mission(GameData.MISSIONS[0])
	log.append("xp_tras_completar=%d" % GameState.xp)
	var f := FileAccess.open("/tmp/odeatest.txt", FileAccess.WRITE)
	if f:
		f.store_string("\n".join(log))
		f.close()
	print("AUTOTEST:\n" + "\n".join(log))
	get_tree().quit()

func _process(delta: float) -> void:
	t += delta
	for p in planets:
		var node: Node3D = p.node
		node.rotate_y(delta * float(p.spin))
	# movimiento por joystick
	if avatar and move_dir.length() > 0.05 and not walking:
		var mv := move_dir * walk_speed * delta
		avatar.global_position += mv
		var look := avatar.global_position + move_dir
		avatar.look_at(look, Vector3.UP)
		_animate_walk(9.0)
	elif not walking:
		_animate_walk(0.0)
	# viaje automatico al planeta
	if walking and avatar:
		var to := target_pos - avatar.global_position
		to.y = 0.0
		var dist := to.length()
		var p: Dictionary = planets[target_chapter]
		var stop_at: float = float(p.radius) + 1.8
		if dist > stop_at:
			var dir := to.normalized()
			avatar.global_position += dir * min(walk_speed * 1.5 * delta, dist - stop_at)
			avatar.look_at(avatar.global_position + dir, Vector3.UP)
			_animate_walk(14.0)
		else:
			walking = false
			_animate_walk(0.0)
			current_chapter = target_chapter
			_open_missions(target_chapter)
			_toast("¡Llegaste a %s!" % str(GameData.CHAPTERS[target_chapter].title))
	if cam and avatar:
		var goal := avatar.global_position + Vector3(7.0, 13.0, 12.0)
		cam.global_position = cam.global_position.lerp(goal, clampf(delta * 3.0, 0.0, 1.0))
		cam.look_at(avatar.global_position + Vector3(0, 1.2, 0), Vector3.UP)
	if cape:
		cape.rotation.x = sin(t * 5.0) * 0.16
	# marcador de toque
	if touch_marker and marker_t < 1.0:
		marker_t += delta * 1.6
		touch_marker.queue_redraw()
	if shot:
		frames += 1
		if frames == 70:
			var img: Image = get_viewport().get_texture().get_image()
			img.save_png("/tmp/odeashot.png")
			get_tree().quit()

# ─────────────────────────── construccion

func _build_env() -> void:
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sm := ShaderMaterial.new()
	var sh := Shader.new()
	sh.code = SKY_SHADER
	sm.shader = sh
	sky.sky_material = sm
	env.sky = sky
	env.glow_enabled = true
	env.glow_intensity = 0.85
	env.glow_bloom = 0.22
	env.glow_hdr_threshold = 0.9
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.3, 0.35, 0.5)
	env.ambient_light_energy = 0.55
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.light_energy = 1.15
	sun.rotation_degrees = Vector3(-40.0, 30.0, 0.0)
	add_child(sun)

func _planet_pos(i: int) -> Vector3:
	var ang := float(i) * 0.785
	var rad := 12.0 + float(i % 3) * 2.6
	return Vector3(cos(ang) * rad, 0.0, sin(ang) * rad)

func _build_planets() -> void:
	for i in CHAPTER_COUNT:
		var ch: Dictionary = GameData.CHAPTERS[i]
		var base := Color(ch.color)
		var pos := _planet_pos(i)
		var radius := 2.1 + float(i % 3) * 0.45      # planetas PEQUENOS
		var node := Node3D.new()
		node.position = pos
		add_child(node)
		var body := MeshInstance3D.new()
		var sph := SphereMesh.new()
		sph.radius = radius
		sph.height = radius * 2.0
		sph.radial_segments = 40
		sph.rings = 20
		body.mesh = sph
		var pm := ShaderMaterial.new()
		var psh := Shader.new()
		psh.code = PLANET_SHADER
		pm.shader = psh
		pm.set_shader_parameter("base_color", Vector3(base.r, base.g, base.b))
		pm.set_shader_parameter("city_color", Vector3(0.9, 1.0, 0.95))
		pm.set_shader_parameter("seed", float(i) * 3.7)
		body.material_override = pm
		node.add_child(body)
		var atmo := MeshInstance3D.new()
		var s2 := SphereMesh.new()
		s2.radius = radius * 1.28
		s2.height = radius * 2.56
		s2.radial_segments = 28
		s2.rings = 14
		atmo.mesh = s2
		var am := ShaderMaterial.new()
		var ash := Shader.new()
		ash.code = ATMO_SHADER
		am.shader = ash
		am.set_shader_parameter("glow_color", Vector3(base.r, base.g, base.b))
		atmo.material_override = am
		node.add_child(atmo)
		if i % 2 == 1:
			var ringm := MeshInstance3D.new()
			var tor := TorusMesh.new()
			tor.inner_radius = radius * 1.5
			tor.outer_radius = radius * 2.0
			tor.rings = 40
			tor.ring_segments = 10
			ringm.mesh = tor
			var rmat := StandardMaterial3D.new()
			rmat.albedo_color = Color(base.r, base.g, base.b, 0.6)
			rmat.emission_enabled = true
			rmat.emission = base
			rmat.emission_energy_multiplier = 0.7
			rmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			ringm.material_override = rmat
			ringm.rotation_degrees = Vector3(16.0, 0.0, 14.0)
			node.add_child(ringm)
		# numero del capitulo flotando
		var lbl := Label3D.new()
		lbl.text = str(i + 1)
		lbl.font_size = 96
		lbl.outline_size = 18
		lbl.modulate = base
		lbl.position = Vector3(0, radius + 1.1, 0)
		lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		lbl.no_depth_test = false
		node.add_child(lbl)
		planets.append({"node": node, "chapter": i, "radius": radius, "pos": pos, "spin": 0.07 + float(i % 3) * 0.04})

func _mat(c: Color, emis: float, rough: float, metal: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	if emis > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = emis
	return m

func _build_avatar() -> void:
	avatar = Node3D.new()
	avatar.scale = Vector3.ONE * AVATAR_SCALE
	add_child(avatar)
	var cyan := Color(0.0, 1.0, 0.85)
	var magenta := Color(1.0, 0.35, 0.85)
	var violet := Color(0.55, 0.4, 1.0)
	var skin := Color(0.98, 0.86, 0.72)
	# ── piernas (con botas)
	for sx in [-1.0, 1.0]:
		var leg := MeshInstance3D.new()
		var lb := CapsuleMesh.new()
		lb.radius = 0.11
		lb.height = 0.62
		leg.mesh = lb
		leg.position = Vector3(0.16 * sx, -0.62, 0.0)
		leg.material_override = _mat(violet, 0.25, 0.5, 0.2)
		avatar.add_child(leg)
		legs.append(leg)
		var boot := MeshInstance3D.new()
		var bb := BoxMesh.new()
		bb.size = Vector3(0.24, 0.18, 0.34)
		boot.mesh = bb
		boot.position = Vector3(0.16 * sx, -0.92, 0.06)
		boot.material_override = _mat(cyan, 0.9, 0.4, 0.3)
		avatar.add_child(boot)
	# ── torso con peto
	var torso := MeshInstance3D.new()
	var cap := CapsuleMesh.new()
	cap.radius = 0.3
	cap.height = 1.0
	torso.mesh = cap
	torso.position.y = 0.22
	torso.material_override = _mat(cyan, 0.5, 0.45, 0.35)
	avatar.add_child(torso)
	var chest := MeshInstance3D.new()
	var cb := BoxMesh.new()
	cb.size = Vector3(0.42, 0.34, 0.2)
	chest.mesh = cb
	chest.position = Vector3(0.0, 0.42, 0.22)
	chest.material_override = _mat(Color(0.1, 0.14, 0.25), 1.5, 0.3, 0.6)
	avatar.add_child(chest)
	# ── brazos
	for sx in [-1.0, 1.0]:
		var arm := MeshInstance3D.new()
		var ab := CapsuleMesh.new()
		ab.radius = 0.085
		ab.height = 0.5
		arm.mesh = ab
		arm.position = Vector3(0.4 * sx, 0.3, 0.0)
		arm.material_override = _mat(magenta, 0.35, 0.45, 0.25)
		avatar.add_child(arm)
		arms.append(arm)
		var shoulder := MeshInstance3D.new()
		var sb := SphereMesh.new()
		sb.radius = 0.14
		sb.height = 0.28
		shoulder.mesh = sb
		shoulder.position = Vector3(0.4 * sx, 0.55, 0.0)
		shoulder.material_override = _mat(cyan, 1.3, 0.3, 0.5)
		avatar.add_child(shoulder)
	# ── cabeza + casco + visor brillante + orejeras
	var head := MeshInstance3D.new()
	var hs := SphereMesh.new()
	hs.radius = 0.3
	hs.height = 0.6
	head.mesh = hs
	head.position.y = 1.0
	head.material_override = _mat(skin, 0.15, 0.7, 0.0)
	avatar.add_child(head)
	var helm := MeshInstance3D.new()
	var hm := SphereMesh.new()
	hm.radius = 0.335
	hm.height = 0.67
	helm.mesh = hm
	helm.position.y = 1.02
	helm.material_override = _mat(Color(0.15, 0.18, 0.3), 1.1, 0.25, 0.8)
	avatar.add_child(helm)
	var visor := MeshInstance3D.new()
	var vb := BoxMesh.new()
	vb.size = Vector3(0.46, 0.16, 0.12)
	visor.mesh = vb
	visor.position = Vector3(0.0, 1.03, 0.28)
	visor.material_override = _mat(Color(0.6, 1.0, 1.0), 2.6, 0.1, 0.9)
	avatar.add_child(visor)
	var fin := MeshInstance3D.new()
	var fb := BoxMesh.new()
	fb.size = Vector3(0.08, 0.3, 0.5)
	fin.mesh = fb
	fin.position = Vector3(0.0, 1.3, -0.05)
	fin.material_override = _mat(magenta, 1.8, 0.3, 0.4)
	avatar.add_child(fin)
	# ── mochila con propulsores
	var pack := MeshInstance3D.new()
	var pb := BoxMesh.new()
	pb.size = Vector3(0.44, 0.5, 0.22)
	pack.mesh = pb
	pack.position = Vector3(0.0, 0.3, -0.32)
	pack.material_override = _mat(Color(0.18, 0.22, 0.36), 0.5, 0.4, 0.6)
	avatar.add_child(pack)
	for sx in [-1.0, 1.0]:
		var thr := MeshInstance3D.new()
		var tb := CylinderMesh.new()
		tb.top_radius = 0.09
		tb.bottom_radius = 0.12
		tb.height = 0.3
		thr.mesh = tb
		thr.position = Vector3(0.24 * sx, 0.12, -0.36)
		thr.rotation_degrees = Vector3(90, 0, 0)
		thr.material_override = _mat(Color(1.0, 0.7, 0.2), 3.0, 0.2, 0.5)
		avatar.add_child(thr)
	# ── capa neón
	cape = Node3D.new()
	cape.position = Vector3(0.0, 0.62, -0.2)
	var cm := MeshInstance3D.new()
	var cp := BoxMesh.new()
	cp.size = Vector3(0.6, 0.9, 0.06)
	cm.mesh = cp
	cm.position = Vector3(0.0, -0.5, 0.0)
	cm.material_override = _mat(Color(1.0, 0.25, 0.7), 1.2, 0.5, 0.1)
	cape.add_child(cm)
	avatar.add_child(cape)

func _animate_walk(speed: float) -> void:
	var ph := sin(t * 9.0) * speed * 0.12
	var ph2 := sin(t * 9.0 + PI) * speed * 0.12
	if legs.size() >= 2:
		legs[0].rotation_degrees.x = ph
		legs[1].rotation_degrees.x = ph2
	if arms.size() >= 2:
		arms[0].rotation_degrees.x = ph2 * 0.8
		arms[1].rotation_degrees.x = ph * 0.8

func _build_camera() -> void:
	cam = Camera3D.new()
	cam.position = Vector3(7.0, 13.0, 12.0)
	cam.fov = 68.0
	add_child(cam)
	cam.look_at(Vector3.ZERO, Vector3.UP)

# ─────────────────────────── UI (menus visibles)

func _btn(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 84)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.add_theme_font_size_override("font_size", 15)
	b.pressed.connect(cb)
	return b

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 10
	add_child(layer)

	# ── barra superior (nivel + XP)
	var top := PanelContainer.new()
	top.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top.offset_bottom = 104
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var tsb := StyleBoxFlat.new()
	tsb.bg_color = Color(0.03, 0.02, 0.09, 0.88)
	tsb.border_color = Color(0.0, 1.0, 0.85, 0.8)
	tsb.border_width_bottom = 2
	tsb.set_content_margin_all(12)
	top.add_theme_stylebox_override("panel", tsb)
	layer.add_child(top)
	var tv := VBoxContainer.new()
	tv.add_theme_constant_override("separation", 2)
	top.add_child(tv)
	hud_level = Label.new()
	hud_level.add_theme_font_size_override("font_size", 18)
	hud_level.add_theme_color_override("font_color", Color(0.0, 1.0, 0.85))
	tv.add_child(hud_level)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	tv.add_child(row)
	xp_bar_bg = ColorRect.new()
	xp_bar_bg.color = Color(1, 1, 1, 0.15)
	xp_bar_bg.custom_minimum_size = Vector2(0, 12)
	xp_bar_bg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(xp_bar_bg)
	xp_bar_fill = ProgressBar.new()
	xp_bar_fill.show_percentage = false
	xp_bar_fill.custom_minimum_size = Vector2(0, 14)
	xp_bar_fill.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	xp_bar_fill.max_value = 100.0
	xp_bar_fill.value = 0.0
	row.add_child(xp_bar_fill)
	hud_xp = Label.new()
	hud_xp.add_theme_font_size_override("font_size", 12)
	row.add_child(hud_xp)

	# ── pista
	hud_hint = Label.new()
	hud_hint.set_anchors_preset(Control.PRESET_TOP_WIDE)
	hud_hint.offset_top = 112
	hud_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hud_hint.add_theme_font_size_override("font_size", 13)
	hud_hint.add_theme_color_override("font_color", Color(1, 1, 1, 0.85))
	hud_hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(hud_hint)

	# ── barra inferior con botones grandes
	var bottom := PanelContainer.new()
	bottom.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	bottom.offset_top = -104
	var bsb := StyleBoxFlat.new()
	bsb.bg_color = Color(0.03, 0.02, 0.09, 0.9)
	bsb.border_color = Color(1.0, 0.35, 0.85, 0.8)
	bsb.border_width_top = 2
	bsb.set_content_margin_all(10)
	bottom.add_theme_stylebox_override("panel", bsb)
	layer.add_child(bottom)
	var bh := HBoxContainer.new()
	bh.add_theme_constant_override("separation", 8)
	bottom.add_child(bh)
	bh.add_child(_btn("MISIONES", func() -> void: _open_missions(current_chapter if current_chapter >= 0 else 0)))
	bh.add_child(_btn("PROGRESO", func() -> void: _toggle_side(true)))
	bh.add_child(_btn("CENTRAR", func() -> void: _center_view()))

	# ── marcador de toque
	touch_marker = Node2D.new()
	touch_marker.draw.connect(func() -> void: _draw_touch_marker())
	layer.add_child(touch_marker)

	# ── joystick virtual
	joystick = Control.new()
	joystick.set_anchors_preset(Control.PRESET_FULL_RECT)
	joystick.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(joystick)

	# ── panel de misiones
	panel_missions = PanelContainer.new()
	panel_missions.set_anchors_preset(Control.PRESET_CENTER)
	panel_missions.custom_minimum_size = Vector2(500, 520)
	panel_missions.position = Vector2(20, 250)
	panel_missions.visible = false
	var msb := StyleBoxFlat.new()
	msb.bg_color = Color(0.03, 0.02, 0.08, 0.97)
	msb.border_color = Color(0.0, 1.0, 0.85, 0.95)
	msb.set_border_width_all(2)
	msb.set_corner_radius_all(14)
	msb.set_content_margin_all(14)
	panel_missions.add_theme_stylebox_override("panel", msb)
	layer.add_child(panel_missions)
	var mscroll := ScrollContainer.new()
	mscroll.custom_minimum_size = Vector2(470, 480)
	panel_missions.add_child(mscroll)
	missions_box = VBoxContainer.new()
	missions_box.custom_minimum_size = Vector2(460, 0)
	missions_box.add_theme_constant_override("separation", 8)
	mscroll.add_child(missions_box)

	# ── panel lateral (barra lateral de progreso)
	panel_side = PanelContainer.new()
	panel_side.set_anchors_preset(Control.PRESET_LEFT_WIDE)
	panel_side.custom_minimum_size = Vector2(330, 0)
	panel_side.offset_right = 330
	panel_side.offset_top = 104
	panel_side.offset_bottom = -104
	panel_side.visible = false
	var ssb := StyleBoxFlat.new()
	ssb.bg_color = Color(0.04, 0.02, 0.1, 0.97)
	ssb.border_color = Color(1.0, 0.35, 0.85, 0.9)
	ssb.border_width_right = 2
	ssb.set_content_margin_all(14)
	panel_side.add_theme_stylebox_override("panel", ssb)
	layer.add_child(panel_side)
	var sscroll := ScrollContainer.new()
	sscroll.custom_minimum_size = Vector2(300, 600)
	panel_side.add_child(sscroll)
	side_box = VBoxContainer.new()
	side_box.custom_minimum_size = Vector2(290, 0)
	side_box.add_theme_constant_override("separation", 8)
	sscroll.add_child(side_box)

	# ── toast (mensajes)
	toast = Label.new()
	toast.set_anchors_preset(Control.PRESET_TOP_WIDE)
	toast.offset_top = 150
	toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast.add_theme_font_size_override("font_size", 16)
	toast.add_theme_color_override("font_color", Color(1.0, 0.9, 0.4))
	toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(toast)

func _toast(msg: String) -> void:
	if toast == null:
		return
	toast.text = msg
	toast.modulate.a = 1.0
	var tw := create_tween()
	tw.tween_interval(2.4)
	tw.tween_property(toast, "modulate:a", 0.0, 1.2)

func _refresh_hud() -> void:
	if hud_level == null:
		return
	hud_level.text = "NIVEL %d · %s" % [GameState.level_index() + 1, GameState.level_name()]
	if hud_xp:
		hud_xp.text = "%d XP" % GameState.xp
	if xp_bar_fill:
		xp_bar_fill.value = GameState.level_progress() * 100.0
	if hud_hint:
		hud_hint.text = "Tocá un planeta para viajar · Arrastrá el dedo para caminar"

func _center_view() -> void:
	if avatar:
		avatar.global_position = Vector3.ZERO
		_toast("Volviste al centro de la galaxia")

func _toggle_side(show_it: bool) -> void:
	if panel_side == null:
		return
	panel_side.visible = show_it
	if show_it:
		_fill_side()

func _fill_side() -> void:
	if side_box == null:
		return
	for c in side_box.get_children():
		c.queue_free()
	var title := Label.new()
	title.text = "TU PROGRESO"
	title.add_theme_font_size_override("font_size", 17)
	title.add_theme_color_override("font_color", Color(1.0, 0.35, 0.85))
	side_box.add_child(title)
	var total := 0
	var done := 0
	for m in GameData.MISSIONS:
		total += 1
		if GameState.is_done(str(m.id)):
			done += 1
	var gen := Label.new()
	gen.add_theme_font_size_override("font_size", 13)
	gen.text = "Misiones: %d / %d   ·   XP: %d" % [done, total, GameState.xp]
	side_box.add_child(gen)
	side_box.add_child(HSeparator.new())
	for i in CHAPTER_COUNT:
		var chd: Dictionary = GameData.CHAPTERS[i]
		var lbl := Label.new()
		lbl.add_theme_font_size_override("font_size", 12)
		lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		lbl.custom_minimum_size = Vector2(280, 0)
		var dc := GameState.chapter_done(i)
		var tc := GameState.chapter_total(i)
		var mark := "✅" if GameState.chapter_complete(i) else ("🔓" if GameState.chapter_unlocked(i) else "🔒")
		lbl.text = "%s %s — %d/%d" % [mark, str(chd.title), dc, tc]
		lbl.add_theme_color_override("font_color", Color(chd.color))
		side_box.add_child(lbl)
	side_box.add_child(HSeparator.new())
	var close := Button.new()
	close.text = "CERRAR"
	close.custom_minimum_size = Vector2(0, 64)
	close.pressed.connect(func() -> void: _toggle_side(false))
	side_box.add_child(close)

func _open_missions(ch: int) -> void:
	if panel_missions == null:
		return
	for c in missions_box.get_children():
		c.queue_free()
	var chd: Dictionary = GameData.CHAPTERS[ch]
	var title := Label.new()
	title.text = "%s — %s" % [str(chd.code), str(chd.title)]
	title.add_theme_font_size_override("font_size", 16)
	title.add_theme_color_override("font_color", Color(chd.color))
	title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	title.custom_minimum_size = Vector2(450, 0)
	missions_box.add_child(title)
	if not GameState.chapter_unlocked(ch):
		var lock_lbl := Label.new()
		lock_lbl.text = "🔒 Completá el capítulo anterior para desbloquear"
		lock_lbl.add_theme_font_size_override("font_size", 13)
		missions_box.add_child(lock_lbl)
	for m in GameData.MISSIONS:
		if int(m.chapter) != ch:
			continue
		var row := HBoxContainer.new()
		var lbl := Label.new()
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		lbl.add_theme_font_size_override("font_size", 13)
		lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		lbl.custom_minimum_size = Vector2(320, 0)
		lbl.text = "%s  (+%d XP)" % [str(m.title), int(m.xp)]
		if GameState.is_done(str(m.id)):
			lbl.add_theme_color_override("font_color", Color(0.45, 1.0, 0.6))
		row.add_child(lbl)
		if not GameState.is_done(str(m.id)):
			var b := Button.new()
			b.text = "COMPLETAR"
			b.custom_minimum_size = Vector2(110, 52)
			b.add_theme_font_size_override("font_size", 12)
			var mm: Dictionary = m
			var cc := ch
			b.pressed.connect(func() -> void:
				GameState.complete_mission(mm)
				_refresh_hud()
				_open_missions(cc)
				_toast("+%d XP!" % int(mm.xp))
			)
			row.add_child(b)
		else:
			var ok := Label.new()
			ok.text = "✔"
			ok.add_theme_color_override("font_color", Color(0.45, 1.0, 0.6))
			row.add_child(ok)
		missions_box.add_child(row)
	for bs in GameData.BOSSES:
		if int(bs.chapter) != ch:
			continue
		var boss := Label.new()
		boss.add_theme_font_size_override("font_size", 14)
		boss.add_theme_color_override("font_color", Color(1.0, 0.2, 0.33))
		boss.text = ("👑 JEFE DERROTADO: " if GameState.chapter_complete(ch) else "⚔️ JEFE FINAL: ") + str(bs.name)
		boss.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		boss.custom_minimum_size = Vector2(450, 0)
		missions_box.add_child(boss)
		break
	var close := Button.new()
	close.text = "CERRAR"
	close.custom_minimum_size = Vector2(0, 60)
	close.pressed.connect(func() -> void: panel_missions.visible = false)
	missions_box.add_child(close)
	panel_missions.visible = true

# ─────────────────────────── toques y joystick

func _planet_screen(ch: int) -> Vector2:
	var node: Node3D = planets[ch].node
	return cam.unproject_position(node.global_position)

func _hit_planet(pos: Vector2) -> int:
	var best := -1
	var best_d := 1e9
	var vsize: Vector2 = get_viewport().get_visible_rect().size
	var umbral: float = max(110.0, vsize.x * 0.22)
	for p in planets:
		var node: Node3D = p.node
		if cam.is_position_behind(node.global_position):
			continue
		var sp := cam.unproject_position(node.global_position)
		var d := sp.distance_to(pos)
		if d < best_d:
			best_d = d
			best = int(p.chapter)
	if best >= 0 and best_d <= umbral:
		return best
	return -1

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var st: InputEventScreenTouch = event
		if st.pressed:
			touch_index = st.index
			touch_start = st.position
			joy_active = true
			_show_marker(st.position)
		else:
			if st.index == touch_index:
				touch_index = -1
				joy_active = false
				move_dir = Vector3.ZERO
	elif event is InputEventScreenDrag:
		var sd: InputEventScreenDrag = event
		if sd.index == touch_index and joy_active:
			var diff := sd.position - touch_start
			if diff.length() > 26.0:
				var fwd := -cam.global_transform.basis.z
				fwd.y = 0.0
				fwd = fwd.normalized()
				var rgt := cam.global_transform.basis.x
				rgt.y = 0.0
				rgt = rgt.normalized()
				move_dir = (rgt * diff.x - fwd * diff.y).normalized()
				_show_marker(sd.position)
	elif event is InputEventMouseButton:
		var mb: InputEventMouseButton = event
		if mb.pressed and mb.button_index == MOUSE_BUTTON_LEFT:
			_tap(mb.position)
	elif event is InputEventMouseMotion and (event.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0:
		move_dir = Vector3(0.0, 0.0, 0.0)

func _tap(pos: Vector2) -> void:
	var ch := _hit_planet(pos)
	if ch < 0:
		_toast("Tocá un planeta para viajar 🌍")
		return
	if not GameState.chapter_unlocked(ch):
		_toast("🔒 Ese mundo está bloqueado: completá el capítulo anterior")
		return
	walking = true
	target_chapter = ch
	target_pos = planets[ch].pos
	_toast("Viajando a %s..." % str(GameData.CHAPTERS[ch].title))

var marker_pos := Vector2.ZERO
var marker_t := 0.0
func _show_marker(p: Vector2) -> void:
	marker_pos = p
	marker_t = 0.0
	if touch_marker:
		touch_marker.queue_redraw()

func _draw_touch_marker() -> void:
	if touch_marker == null or marker_t >= 1.0:
		return
	var a: float = 1.0 - marker_t
	touch_marker.draw_arc(marker_pos, 26.0 + marker_t * 34.0, 0.0, TAU, 32, Color(0.0, 1.0, 0.9, a), 3.0, true)
