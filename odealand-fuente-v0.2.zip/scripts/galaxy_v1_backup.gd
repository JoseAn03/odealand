extends Node3D
## ODEALAND — Galaxia 3D (estilo Mario Galaxy)
## Planetas esfericos por capitulo, avatar que camina hacia el mundo que toques,
## misiones jugables con XP y jefes finales.

const CHAPTER_COUNT := 8
const SKY_SHADER := """
shader_type sky;
uniform vec3 top_col : source_color = vec3(0.02, 0.01, 0.06);
uniform vec3 bot_col : source_color = vec3(0.12, 0.02, 0.18);
void sky() {
	float h = clamp(EYEDIR.y * 0.5 + 0.5, 0.0, 1.0);
	vec3 col = mix(bot_col, top_col, h);
	vec3 d = floor(EYEDIR * 320.0);
	float s = step(0.9972, fract(sin(dot(d, vec3(12.9898, 78.233, 45.164))) * 43758.5453));
	float tw = 0.7 + 0.3 * sin(TIME * 2.0 + d.x);
	COLOR = col + vec3(s * tw) * 0.95;
}
"""
const PLANET_SHADER := """
shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, diffuse_burley, specular_schlick_ggx;
uniform vec3 base_color : source_color = vec3(0.1, 0.3, 0.4);
uniform vec3 city_color : source_color = vec3(0.0, 1.0, 0.8);
uniform float seed = 0.0;
varying vec3 v_local;
float hash(vec3 p) {
	p = fract(p * 0.3183099 + vec3(0.11, 0.17, 0.23));
	p *= 17.0;
	return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}
float noise(vec3 x) {
	vec3 i = floor(x);
	vec3 f = fract(x);
	f = f * f * (3.0 - 2.0 * f);
	return mix(mix(mix(hash(i), hash(i + vec3(1,0,0)), f.x),
	               mix(hash(i + vec3(0,1,0)), hash(i + vec3(1,1,0)), f.x), f.y),
	           mix(mix(hash(i + vec3(0,0,1)), hash(i + vec3(1,0,1)), f.x),
	               mix(hash(i + vec3(0,1,1)), hash(i + vec3(1,1,1)), f.x), f.y), f.z);
}
float fbm(vec3 p) {
	float v = 0.0;
	float a = 0.5;
	for (int i = 0; i < 4; i++) { v += a * noise(p); p *= 2.03; a *= 0.5; }
	return v;
}
void vertex() { v_local = VERTEX; }
void fragment() {
	float n = fbm(v_local * 1.7 + seed);
	float land = smoothstep(0.40, 0.60, n);
	vec3 col = mix(base_color * 0.22, base_color, land);
	float c = step(0.70, hash(floor(v_local * 22.0) + seed));
	float coast = 1.0 - smoothstep(0.50, 0.72, n);
	vec3 emis = city_color * c * land * coast;
	float g = max(abs(sin(v_local.y * 5.0)), max(abs(sin(v_local.x * 5.0)), abs(sin(v_local.z * 5.0))));
	ALBEDO = col + vec3(smoothstep(0.965, 1.0, g) * 0.07);
	EMISSION = emis * 1.9;
	ROUGHNESS = 0.85;
	METALLIC = 0.08;
}
"""
const ATMO_SHADER := """
shader_type spatial;
render_mode blend_add, cull_front, unshaded, depth_draw_never;
uniform vec3 glow_color : source_color = vec3(0.0, 1.0, 0.9);
uniform float power = 2.4;
void fragment() {
	float f = pow(1.0 - abs(dot(NORMAL, VIEW)), power);
	ALBEDO = glow_color * f;
	EMISSION = glow_color * f * 1.6;
}
"""

var planets: Array = []
var avatar: Node3D
var legs: Array = []
var arms: Array = []
var cam: Camera3D
var t := 0.0
var walk_speed := 9.0
var walking := false
var target_chapter := -1
var target_pos := Vector3.ZERO
var current_chapter := -1
var shot := false
var frames := 0
var hud: Label
var status: Label
var panel: Control
var panel_title: Label
var panel_box: VBoxContainer

func _ready() -> void:
	randomize()
	if OS.get_environment("ODEASHOT") == "1":
		shot = true
	_build_environment()
	_build_planets()
	_build_avatar()
	_build_camera()
	_build_ui()
	_refresh_hud()

func _process(delta: float) -> void:
	t += delta
	# planetas girando + flotando
	for p in planets:
		var node: Node3D = p.node
		node.rotate_y(delta * p.spin)
		node.position.y = p.base_y + sin(t * 0.8 + float(p.chapter) * 0.7) * 0.35
	# caminar
	if walking and avatar:
		var to := target_pos - avatar.global_position
		to.y = 0.0
		var d := to.length()
		var p: Dictionary = planets[target_chapter]
		var stop_at: float = float(p.radius) + 2.2
		if d > stop_at:
			var dir := to.normalized()
			avatar.global_position += dir * min(walk_speed * delta, d - stop_at)
			avatar.look_at(avatar.global_position + dir, Vector3.UP)
			_animate_walk(delta, 9.0)
			# particulas de propulsion
			_spawn_trail()
		else:
			walking = false
			_animate_walk(0.0, 0.0)
			_land_on_planet(target_chapter)
			_open_panel(target_chapter)
	# camara sigue
	if cam and avatar:
		var goal := avatar.global_position + Vector3(9.0, 11.0, 13.0)
		cam.global_position = cam.global_position.lerp(goal, clampf(delta * 3.2, 0.0, 1.0))
		cam.look_at(avatar.global_position + Vector3(0, 1.0, 0), Vector3.UP)
	# screenshot automatico (verificacion)
	if shot:
		frames += 1
		if frames == 60:
			var img: Image = get_viewport().get_texture().get_image()
			img.save_png("/tmp/odeashot.png")
			get_tree().quit()

var trail_nodes: Array = []
func _spawn_trail() -> void:
	if randf() > 0.25:
		return
	var m := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.09
	sm.height = 0.18
	m.mesh = sm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.0, 1.0, 0.85, 0.9)
	mat.emission_enabled = true
	mat.emission = Color(0.0, 1.0, 0.85)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.material_override = mat
	m.global_position = avatar.global_position + Vector3(0, 0.2, 0) - avatar.global_transform.basis.z * 0.6
	add_child(m)
	trail_nodes.append({"n": m, "life": 1.0})
	# limpiar viejos
	if trail_nodes.size() > 90:
		var old: Dictionary = trail_nodes.pop_front()
		var on: Node3D = old.n
		if is_instance_valid(on):
			on.queue_free()

func _physics_process(delta: float) -> void:
	for e in trail_nodes:
		e.life -= delta * 0.9

# ─────────────────────────── construccion
func _build_environment() -> void:
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sm := ShaderMaterial.new()
	var sh := Shader.new()
	sh.code = SKY_SHADER
	sm.shader = sh
	sky.sky_material = sm
	env.sky = sky
	env.glow_enabled = true
	env.glow_intensity = 0.9
	env.glow_bloom = 0.25
	env.glow_hdr_threshold = 0.85
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.25, 0.3, 0.45)
	env.ambient_light_energy = 0.5
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.light_energy = 1.1
	sun.rotation_degrees = Vector3(-38.0, 35.0, 0.0)
	sun.shadow_enabled = false
	add_child(sun)

func _planet_pos(i: int) -> Vector3:
	# distribucion en arco/galaxia
	var ring := float(i) * 0.79
	var radius := 15.0 + float(i % 3) * 4.5
	return Vector3(cos(ring) * radius, 0.0, sin(ring) * radius)

func _build_planets() -> void:
	for i in CHAPTER_COUNT:
		var ch: Dictionary = GameData.CHAPTERS[i]
		var base := Color(ch.color)
		var pos := _planet_pos(i)
		var radius := 5.0 + float((i * 7) % 4) * 0.9
		var node := Node3D.new()
		node.position = pos
		add_child(node)
		# cuerpo
		var body := MeshInstance3D.new()
		var sph := SphereMesh.new()
		sph.radius = radius
		sph.height = radius * 2.0
		sph.radial_segments = 48
		sph.rings = 24
		body.mesh = sph
		var pm := ShaderMaterial.new()
		var psh := Shader.new()
		psh.code = PLANET_SHADER
		pm.shader = psh
		pm.set_shader_parameter("base_color", Vector3(base.r, base.g, base.b))
		pm.set_shader_parameter("city_color", Vector3(0.85, 1.0, 0.95))
		pm.set_shader_parameter("seed", float(i) * 3.7)
		body.material_override = pm
		node.add_child(body)
		# atmosfera
		var atmo := MeshInstance3D.new()
		var s2 := SphereMesh.new()
		s2.radius = radius * 1.22
		s2.height = radius * 2.44
		s2.radial_segments = 32
		s2.rings = 16
		atmo.mesh = s2
		var am := ShaderMaterial.new()
		var ash := Shader.new()
		ash.code = ATMO_SHADER
		am.shader = ash
		am.set_shader_parameter("glow_color", Vector3(base.r, base.g, base.b))
		atmo.material_override = am
		node.add_child(atmo)
		# anillo (personalizacion por planeta)
		if i % 3 == 1:
			var ringm := MeshInstance3D.new()
			var tor := TorusMesh.new()
			tor.inner_radius = radius * 1.5
			tor.outer_radius = radius * 1.95
			tor.rings = 48
			tor.ring_segments = 12
			ringm.mesh = tor
			var rmat := StandardMaterial3D.new()
			rmat.albedo_color = Color(base.r, base.g, base.b, 0.55)
			rmat.emission_enabled = true
			rmat.emission = base
			rmat.emission_energy_multiplier = 0.6
			rmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			ringm.material_override = rmat
			ringm.rotation_degrees = Vector3(18.0, 0.0, 12.0)
			node.add_child(ringm)
		planets.append({
			"node": node, "chapter": i, "radius": radius,
			"pos": pos, "base_y": 0.0, "spin": 0.08 + float(i % 3) * 0.05
		})

func _build_avatar() -> void:
	avatar = Node3D.new()
	avatar.position = Vector3(0.0, 0.0, 0.0)
	add_child(avatar)
	var cyan := Color(0.0, 1.0, 0.85)
	var magenta := Color(1.0, 0.35, 0.85)
	# torso
	var torso := MeshInstance3D.new()
	var cap := CapsuleMesh.new()
	cap.radius = 0.34
	cap.height = 1.25
	torso.mesh = cap
	torso.position.y = 0.35
	torso.material_override = _mat(cyan, 1.2)
	avatar.add_child(torso)
	# cabeza
	var head := MeshInstance3D.new()
	var hs := SphereMesh.new()
	hs.radius = 0.36
	hs.height = 0.72
	head.mesh = hs
	head.position.y = 1.25
	head.material_override = _mat(Color(0.95, 0.97, 1.0), 0.4)
	avatar.add_child(head)
	# visor
	var visor := MeshInstance3D.new()
	var vb := BoxMesh.new()
	vb.size = Vector3(0.42, 0.14, 0.1)
	visor.mesh = vb
	visor.position = Vector3(0.0, 1.28, 0.3)
	visor.material_override = _mat(cyan, 2.4)
	avatar.add_child(visor)
	# auriculares
	for sx in [-1.0, 1.0]:
		var ear := MeshInstance3D.new()
		var eb := BoxMesh.new()
		eb.size = Vector3(0.1, 0.18, 0.18)
		ear.mesh = eb
		ear.position = Vector3(0.34 * sx, 1.28, 0.0)
		ear.material_override = _mat(magenta, 1.6)
		avatar.add_child(ear)
	# mochila propulsora
	var pack := MeshInstance3D.new()
	var pb := BoxMesh.new()
	pb.size = Vector3(0.5, 0.6, 0.24)
	pack.mesh = pb
	pack.position = Vector3(0.0, 0.5, -0.34)
	pack.material_override = _mat(Color(0.2, 0.25, 0.4), 0.5)
	avatar.add_child(pack)
	# piernas y brazos
	for sx in [-1.0, 1.0]:
		var leg := MeshInstance3D.new()
		var lb := BoxMesh.new()
		lb.size = Vector3(0.18, 0.62, 0.18)
		leg.mesh = lb
		leg.position = Vector3(0.17 * sx, -0.62, 0.0)
		leg.material_override = _mat(cyan.darkened(0.35), 0.6)
		avatar.add_child(leg)
		legs.append(leg)
		var arm := MeshInstance3D.new()
		var ab := BoxMesh.new()
		ab.size = Vector3(0.14, 0.55, 0.14)
		arm.mesh = ab
		arm.position = Vector3(0.46 * sx, 0.42, 0.0)
		arm.material_override = _mat(magenta.darkened(0.25), 0.6)
		avatar.add_child(arm)
		arms.append(arm)

func _mat(c: Color, emis: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.45
	m.metallic = 0.25
	if emis > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = emis
	return m

func _animate_walk(_delta: float, speed: float) -> void:
	var ph := sin(t * 8.0) * speed
	var ph2 := sin(t * 8.0 + PI) * speed
	if legs.size() >= 2:
		legs[0].rotation_degrees.x = ph * 2.0
		legs[1].rotation_degrees.x = ph2 * 2.0
	if arms.size() >= 2:
		arms[0].rotation_degrees.x = ph2 * 1.6
		arms[1].rotation_degrees.x = ph * 1.6

func _build_camera() -> void:
	cam = Camera3D.new()
	cam.position = Vector3(9.0, 11.0, 13.0)
	cam.fov = 62.0
	add_child(cam)
	cam.look_at(Vector3.ZERO, Vector3.UP)

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	hud = Label.new()
	hud.position = Vector2(18, 14)
	hud.add_theme_font_size_override("font_size", 18)
	hud.add_theme_color_override("font_color", Color(0.0, 1.0, 0.85))
	layer.add_child(hud)
	status = Label.new()
	status.position = Vector2(18, 40)
	status.add_theme_font_size_override("font_size", 13)
	status.add_theme_color_override("font_color", Color(1, 1, 1, 0.75))
	layer.add_child(status)
	# panel de misiones
	panel = PanelContainer.new()
	panel.visible = false
	panel.position = Vector2(24, 150)
	panel.custom_minimum_size = Vector2(492, 300)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.03, 0.02, 0.08, 0.95)
	sb.border_color = Color(0.0, 1.0, 0.85, 0.9)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(14)
	sb.set_content_margin_all(14)
	panel.add_theme_stylebox_override("panel", sb)
	layer.add_child(panel)
	panel_box = VBoxContainer.new()
	panel_box.add_theme_constant_override("separation", 6)
	panel.add_child(panel_box)
	panel_title = Label.new()
	panel_title.add_theme_font_size_override("font_size", 17)
	panel_box.add_child(panel_title)
	var close := Button.new()
	close.text = "CERRAR (seguir explorando)"
	close.pressed.connect(func() -> void:
		panel.visible = false
		status.text = "Toca un planeta para viajar 🪐"
	)
	panel_box.add_child(close)

func _refresh_hud() -> void:
	hud.text = "NIVEL %d · %s" % [GameState.level_index() + 1, GameState.level_name()]
	var pct := int(GameState.level_progress() * 100.0)
	status.text = "%d XP · progreso %d%% · toca un planeta para viajar 🪐" % [GameState.xp, pct]

# ─────────────────────────── viaje y misiones
func _land_on_planet(ch: int) -> void:
	var p: Dictionary = planets[ch]
	var node: Node3D = p.node
	var dir := (avatar.global_position - node.global_position)
	dir.y = 0.0
	if dir.length() < 0.001:
		dir = Vector3.FORWARD
	dir = dir.normalized()
	avatar.global_position = node.global_position + dir * (float(p.radius) + 1.5)
	avatar.look_at(node.global_position, Vector3.UP)
	current_chapter = ch
	status.text = "Llegaste a %s" % str(GameData.CHAPTERS[ch].title)

func _open_panel(ch: int) -> void:
	var childs := panel_box.get_children()
	for c in childs:
		if c != panel_title:
			c.queue_free()
	var chd: Dictionary = GameData.CHAPTERS[ch]
	panel_title.text = "%s — %s" % [str(chd.code), str(chd.title)]
	panel_title.add_theme_color_override("font_color", Color(chd.color))
	# misiones
	for m in GameData.MISSIONS:
		if int(m.chapter) != ch:
			continue
		var row := HBoxContainer.new()
		var lbl := Label.new()
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		lbl.add_theme_font_size_override("font_size", 13)
		lbl.text = "%s  (+%d XP)" % [str(m.title), int(m.xp)]
		if GameState.is_done(str(m.id)):
			lbl.add_theme_color_override("font_color", Color(0.4, 1.0, 0.6))
		row.add_child(lbl)
		if not GameState.is_done(str(m.id)):
			var b := Button.new()
			b.text = "COMPLETAR"
			b.add_theme_font_size_override("font_size", 12)
			var mm: Dictionary = m
			b.pressed.connect(func() -> void:
				GameState.complete_mission(mm)
				_refresh_hud()
				_open_panel(ch)
			)
			row.add_child(b)
		else:
			var ok := Label.new()
			ok.text = "✔"
			ok.add_theme_color_override("font_color", Color(0.4, 1.0, 0.6))
			row.add_child(ok)
		panel_box.add_child(row)
	# jefe final
	for bs in GameData.BOSSES:
		if int(bs.chapter) != ch:
			continue
		var boss_lbl := Label.new()
		boss_lbl.add_theme_font_size_override("font_size", 14)
		boss_lbl.add_theme_color_override("font_color", Color("#ff3355"))
		var beaten := GameState.chapter_complete(ch)
		boss_lbl.text = ("👑 JEFE DERROTADO: " if beaten else "⚔️ JEFE FINAL: ") + str(bs.name)
		panel_box.add_child(boss_lbl)
		var d := Label.new()
		d.add_theme_font_size_override("font_size", 11)
		d.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		d.custom_minimum_size = Vector2(450, 0)
		d.text = str(bs.description)
		panel_box.add_child(d)
		break
	var close := Button.new()
	close.text = "CERRAR (seguir explorando)"
	close.pressed.connect(func() -> void:
		panel.visible = false
	)
	panel_box.add_child(close)
	panel.visible = true

# ─────────────────────────── input
func _unhandled_input(event: InputEvent) -> void:
	var pressed := false
	var pos := Vector2.ZERO
	if event is InputEventMouseButton and event.pressed:
		pressed = true
		pos = event.position
	elif event is InputEventScreenTouch and event.pressed:
		pressed = true
		pos = event.position
	if not pressed:
		return
	# elegir el planeta cuyo centro proyectado este mas cerca del toque
	var best := -1
	var best_d := 9999.0
	for p in planets:
		var node: Node3D = p.node
		if cam.is_position_behind(node.global_position):
			continue
		var sp := cam.unproject_position(node.global_position)
		var d: float = sp.distance_to(pos)
		if d < best_d:
			best_d = d
			best = int(p.chapter)
	if best < 0 or best_d > 130.0:
		return
	if not GameState.chapter_unlocked(best):
		status.text = "🔒 Ese mundo está bloqueado: completa el capítulo anterior"
		return
	target_chapter = best
	target_pos = planets[best].pos
	walking = true
	panel.visible = false
	status.text = "Viajando a %s..." % str(GameData.CHAPTERS[best].title)
